Web backdoors from the wild, collected during incident response, submitted, and acquired otherwise.

Antivirus/antimalware bypass:
Most antivirus/antimalware/waf/ids/etc will flag on these immediately, deleting a payload that otherwise could have been successfully uploaded. Basic evasion techniques are likely to work. Try modifying the code so that it's different enough to not trigger pattern-based signatures. Examples - delete comments, replace function names, replace variable names. 

This repo has many more: https://github.com/xl7dev/WebShell

----------------------------------------

Laudanum-1.0 files credits:

- Kevin Johnson
        - Project Lead
- Tim Medin
        - Project Lead
- Justin Searle
        - Core Developer
Additional Coding
- Robin Wood
- Jason Gillam (Wordpress Plugin)
Project Website: http://laudanum.secureideas.net
Sourceforge Site: http://sourceforge.net/projects/laudanum
----------------------------------------
