credits: http://funoverip.net/2010/12/blind-sql-injection-detection-with-burp-suite/
